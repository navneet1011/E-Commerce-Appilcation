const pool= require('../utils/database');
module.exports = class Order{

    constructor( product_id, product_quantity){
        this.product_id = product_id;
        this.product_quantity = product_quantity;
        
    }

    new_function(){
        pool.query('with temp(cart_value) as (select sum(products.price*cart.quantity) from cart inner join products on cart.item_id = products.id) insert into orders (select cart.user_id,cart.item_id,cart.quantity from cart, users, temp where cart.item_id not in (select orders.item_id from orders) and users.user_id = 1 and users.credit >= temp.cart_value)');
        pool.query('with temp(cart_value) as (select sum(products.price*cart.quantity) from cart inner join products on cart.item_id = products.id) update orders set quantity = orders.quantity + cart.quantity from cart, users, temp where orders.user_id = cart.user_id and orders.item_id = cart.item_id and users.user_id = 1 and users.credit >= temp.cart_value');
        pool.query('with temp(cart_value) as (select sum(products.price*cart.quantity) from cart inner join products on cart.item_id = products.id) update users set credit = users.credit - temp.cart_value from temp where users.user_id = 1');
        
        return pool.query('with temp(cart_value) as (select sum(products.price*cart.quantity) from cart inner join products on cart.item_id = products.id) delete from cart using users, temp where quantity<>0 and users.credit >= temp.cart_value');
       
    }

    static get_all(){
        return  pool.query('SELECT products.id,products.title,products.price,products.image,orders.user_id,orders.quantity FROM products INNER JOIN orders on products.id = orders.item_id;');

    };
    

};