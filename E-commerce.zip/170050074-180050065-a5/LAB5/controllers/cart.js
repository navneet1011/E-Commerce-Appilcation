const Prod = require('../models/prod');
const Cart = require('../models/cart');
const Order = require('../models/orders');
const pool= require('../utils/database');


exports.get_test = async (req,res,next) => {
    const results = await Cart.get_all();
    const results1 = await Cart.get_credit();
   
    res.render('admin/cart',{
        pageTitle:'Cart',
        path:'/cart',
        cart_list: results.rows,
        c_list: results1.rows

    });
};

exports.post_test =  async (req,res,next) => {
    
    const check_credit =  await pool.query('select users.credit from cart, products , users, (select sum(cart.quantity * products.price) as price_total from products, cart where  cart.item_id = products.id) as y where users.credit >= y.price_total;');
    if (check_credit.rowCount < 1){
        res.redirect('/cart');
        
    } else{
        const product_id = req.body.product_id;
        const product_quantity = req.body.product_quantity;
        const add_to_order = new Order( product_id, product_quantity);        
        add_to_order
            .new_function()
            .then(() => {
                res.redirect('/orders');
            })
            .catch(err => console.log(err));
    }
};

