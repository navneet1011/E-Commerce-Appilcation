const path = require('path');
const express = require('express');

const OrderCon = require('../controllers/orders');

const router = express.Router();

router.get('/', OrderCon.get_test);

module.exports = router;
