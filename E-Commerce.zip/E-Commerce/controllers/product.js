const Prod = require('../models/prod');
const Cart = require('../models/cart');
const pool = require('../utils/database');

exports.get_test = async (req,res,next) => {
    const results = await Prod.get_all();
   	
    res.render('admin/product',{
        pageTitle:'Products',
        path:'/prods',
        prod_list: results.rows
    });
};


exports.post_test =  async (req,res,next) => {
    const product_id = req.body.product_id;  
    const product__description = req.body.product__description; 
   
    const add_to_cart = new Cart( product_id,product__description);
    add_to_cart
        .add_cart()
        .then(() => {
            res.redirect('/cart');
        })
        .catch(err => console.log(err));
};


