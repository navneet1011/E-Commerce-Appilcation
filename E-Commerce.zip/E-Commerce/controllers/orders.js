const Prod = require('../models/prod');
const Cart = require('../models/cart');
const Order = require('../models/orders')


exports.get_test = async (req,res,next) => {
    const results = await Order.get_all();

   
    res.render('admin/orders',{
        pageTitle:'Order',
        path:'/orders',
        order_list: results.rows
        

    });
};

