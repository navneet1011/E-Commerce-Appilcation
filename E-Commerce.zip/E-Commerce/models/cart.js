const pool= require('../utils/database');
module.exports = class Cart{

    constructor( product_id, product_description){
        this.product_id = product_id;
        this.product_description = product_description;
    }

    async add_cart(){
     
        pool.query('with temp(a,id,quantity) as (select 1,products.id,products.quantity from products where products.id = $1) insert into cart select a,temp.id,temp.quantity/temp.quantity from temp where temp.quantity > 0 on conflict (user_id ,item_id) do update set quantity = cart.quantity + 1',[this.product_id])

        return pool.query('update products set quantity = products.quantity - 1 where products.id = $1 and products.quantity > 0',[this.product_id]);
    };

    static get_all(){
        return  pool.query('SELECT products.id,products.title,products.price,products.image,cart.user_id,cart.quantity FROM products INNER JOIN cart on products.id = cart.item_id;');

    };

    static get_credit(){
        return pool.query('select * from users ');
    }

};